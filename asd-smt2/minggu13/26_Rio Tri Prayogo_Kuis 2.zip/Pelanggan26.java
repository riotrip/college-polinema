package minggu13;

public class Pelanggan26 {
    String namaPelanggan, noHp;
    public int harga;

    Pelanggan26(String namaPelanggan, String noHp) {
        this.namaPelanggan = namaPelanggan;
        this.noHp = noHp;
    }
}
